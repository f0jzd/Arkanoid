#pragma once

void FrameReset(int& frame);

void EditBrick(int i, int j);

void SetStrongwalls();

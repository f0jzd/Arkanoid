#pragma once

float sign(float a);

float clamp(float a, float min, float max);
